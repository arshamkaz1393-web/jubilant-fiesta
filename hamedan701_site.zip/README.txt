همدان ۷۰۱
برای انتشار در GitHub Pages:
۱) فایل index.html را در صفحه اصلی مخزن (همان جایی که README.md قرار دارد) بارگذاری کن.
۲) وارد Settings > Pages شو.
۳) در Build and deployment، گزینه Deploy from a branch را انتخاب کن.
۴) Branch را main و پوشه را /(root) بگذار و Save را بزن.
۵) پس از چند دقیقه سایت با آدرس https://arshamkaz1393-web.github.io/jubilant-fiesta/ در دسترس خواهد بود.
